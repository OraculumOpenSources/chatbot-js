// Levenshtein Distance

function levenshteinDistance(s1, s2) {
    const len1 = s1.length;
    const len2 = s2.length;

    const dp = new Array(len1 + 1).fill(null).map(() => new Array(len2 + 1).fill(null));

    for (let i = 0; i <= len1; i++) {
        for (let j = 0; j <= len2; j++) {
            if (i === 0) {
                dp[i][j] = j;
            } else if (j === 0) {
                dp[i][j] = i;
            } else {
                const cost = s1[i - 1] !== s2[j - 1] ? 1 : 0;
                dp[i][j] = Math.min(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                );
            }
        }
    }

    return dp[len1][len2];
}


// End Levenshtein Distance

// ChatBot Main code

const chatLog = document.getElementById("chat-log");
const userInput = document.getElementById("user-input");
const sendButton = document.getElementById("send-button");

sendButton.addEventListener("click", () => {
    const userMessage = userInput.value;
    addMessage(userMessage, "user");
    handleUserInput(userMessage);
    userInput.value = "";
});

function addMessage(message, sender) {
    const messageElement = document.createElement("div");
    messageElement.classList.add("message", sender);
    messageElement.textContent = message;
    chatLog.appendChild(messageElement);
}

function handleUserInput(userMessage) {
    const cleanedUserMessage = userMessage.replace(/[^\w\s]/gi, "").toLowerCase();
    const bestMatch = findBestMatch(cleanedUserMessage);

    if (bestMatch) {
        addMessage(bestMatch.answer, "chatbot");
    } else {
        addMessage("Mi dispiace, non ho capito.", "chatbot");
    }
}

function findBestMatch(userMessage) {
    let bestMatch = null;
    let minDistance = Infinity;

    for (const qna of qnaDataset) {
        const cleanedQuestion = qna.question.replace(/[^\w\s]/gi, "").toLowerCase();
        const distance = levenshteinDistance(userMessage, cleanedQuestion);

        if (distance < minDistance && distance < 5) {
            minDistance = distance;
            bestMatch = qna;
        }
    }

    return bestMatch;
}


